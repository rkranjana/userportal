export class UserDetail {
    Userid : number;
    Username : string;
    Password : string;
    Fullname : string;
    Emailid : string;
}
