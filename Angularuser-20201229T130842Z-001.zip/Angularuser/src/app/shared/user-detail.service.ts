import { Injectable } from '@angular/core';
import { UserDetail } from './user-detail.model';
import {HttpClient} from "@angular/common/http"
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Injectable({
  providedIn: 'root'
})
export class UserDetailService {
  formData : UserDetail
  readonly rootURL = 'https://localhost:44303/api';
  list : UserDetail[];

  constructor(private http: HttpClient) { }

  postUserDetail(formData:UserDetail){
    return this.http.post(this.rootURL+'/UserDetails', formData);

  }

  refreshList(){
    this.http.get(this.rootURL + '/UserDetails')
    .toPromise()
    .then(res => this.list = res as UserDetail[]);
  }
}
