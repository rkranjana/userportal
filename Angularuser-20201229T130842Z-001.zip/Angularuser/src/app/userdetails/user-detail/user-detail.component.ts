import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { UserDetailService } from 'src/app/shared/user-detail.service';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styles: [
  ]
})
export class UserDetailComponent implements OnInit {

  constructor(public service: UserDetailService,
    private toastr:ToastrService) { }

  ngOnInit(): void {
    this.resetForm();
  }

  resetForm(form?:NgForm){
    if(form!=null)
    form.resetForm();
    this.service.formData = {
      Userid:0,
      Username: '',
      Password: '',
      Fullname: '',
      Emailid: ''

    }
  }

  onSubmit(form:NgForm){
   this.service.postUserDetail(form.value).subscribe(
     res => {
       this.resetForm(form);
       this.toastr.success('Registered Successfully', 'User Registration Portal');

     },
     err => {
       console.log(err);
     }
   )
  }
}
